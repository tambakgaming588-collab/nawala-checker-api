
# NAWALA + KOMINFO Checker API (Render Ready)

Upload to GitHub → Deploy on Render → Done.

Build: `npm install`
Start: `node server.js`

Endpoint:
/check
